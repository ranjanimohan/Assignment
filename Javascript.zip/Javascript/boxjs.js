(function(){
  /*var speed = 1,
  moveBox = function(){
    var el = document.getElementById("box"),
        left = el.offsetLeft,
        moveBy = 3;
    el.style.left = left + moveBy + "px";

    if(left > 399){
      clearTimeout(timer);
    }
  };
  var timer = setInterval(moveBox , speed);
  var el = document.getElementById("box");
  el.keypress = function(){
    this.style.backgroundColor = "red";
  };*/

var buttons = document.getElementByTagName("button");

}());
