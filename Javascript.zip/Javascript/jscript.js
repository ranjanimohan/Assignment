(function(){
  alert("Inside function");
  var names = ["Ranjani","Mohan","Meenakshi"];
  var names1 = ["Sindhu","Venkat"];

  var cc = names.concat(names1);
  var joined = names.join("");
  var reversed = names.reverse();
  var sorted = names.sort();

  alert(cc);
  alert(joined);
  alert(reversed);
  alert("names after reversed " + names);
  alert(sorted);
  if(confirm("Do you want to go to google.com?")){
    location="http://google.com";
  }
  else {
    alert("You stay here!!");
  }
  var pElements = document.getElementsByTagName("head");
  alert(pElements.length);
}());
