var fs = require('fs');
var data = fs.readFileSync("sample.csv");
   var stringData=data.toString();
   var arrayOne= stringData.split('\r\n');
   var header=arrayOne[0].split(',');
   //console.log(header[0]+header[5]);

   var noOfRow=arrayOne.length;
   var noOfCol=2;
   var jArray=[];

   csvtojson(5,"country_pop.json");
   csvtojson(11,"country_gdp.json");
   csvtojson(21,"country_ppp.json");


   //function
   function csvtojson(index,filename){
   var i=0,j=0;
   for (i = 1; i < noOfRow-1; i++) {
      var obj = {};
      var myNewLine=arrayOne[i].split(',');
      for (j = 0; j< noOfCol; j++) {

        var headerText = header[0];
        var valueText = myNewLine[0];
        headerText1 = header[index];
        var valueText1 = myNewLine[index];
        obj[headerText] = valueText;
        obj[headerText1] = valueText1;
      };
        jArray.push(obj);

};
jArray.sort(function(a,b){
  return parseFloat(b[headerText1])-parseFloat(a[headerText1]);
})

console.log( jArray);

fs.writeFile( filename, JSON.stringify( jArray ), "utf8", (err) => {
if (err) throw err;
});

}
